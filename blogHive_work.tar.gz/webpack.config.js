const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const UgLiftJsPlugin = require('uglifyjs-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const OptimizeCSSAssetsPlugin = require("optimize-css-assets-webpack-plugin");
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
const CopyWebpackPlugin = require('copy-webpack-plugin');
const ImgWebpackPlugin = require('imagemin-webpack-plugin').default
const path = require('path');

const config = {
	entry: {
		main: './src/js/article.js',
		//homeRoute: './src/js/index.js',
		homeController: './src/js/homeMC/homeController.js'/*,
		articleController: './src/js/articleMC/articleController.js'*/
	},
	output: {
		path: path.resolve(__dirname, 'dist'),
		filename: '[name].bundle.js'/*,
		publicPath: 'dist/'*/
	},
	module: {
		rules: [
			{
			test: /\.(scss)$/,
			use: [
					{
						loader: MiniCssExtractPlugin.loader
					}, 
					{
						loader: 'css-loader'
					}, 
					{
						loader: 'postcss-loader',
            options: {
              plugins() {
                return [
                  require('autoprefixer')
                ];
              }
            }
					},
					{
						loader: 'sass-loader'
					}
				]
			},
			{
				test: /\.(js)$/,
				exclude: /node_modules/,
				loader: 'babel-loader'
			},
			{
				test: /\.(html)$/,
				use: [
					{
						loader: 'raw-loader'
					}/*,
					{
						loader: 'file-loader',
						options: {
							name: '[name].[ext]'
						}
					}*/
				],
				//exclude: path.resolve(__dirname, 'src/view/index.html')
			}
		]
	},
	plugins: [
		new HtmlWebpackPlugin({
			filename: 'index.html',
			template: './src/view/index.html',
			chunks: ['main', 'homeController']
		}),/*
		new HtmlWebpackPlugin({
			//filename: 'home.html',
			template: './src/view/home.html',
			chunks: ['main', 'home', 'blog']
		}),
		new HtmlWebpackPlugin({
			//filename: 'article.html',
			template: './src/view/article.html',
			chunks: ['main', 'home', 'blog']
		}),*/
		new webpack.ProvidePlugin({
			$: 'jquery',
			jQuery: 'jquery',
			Util: 'exports-loader?Util!bootstrap/js/dist/util'
		}),
		new MiniCssExtractPlugin({
			filename: '[name].bundle.css'
		})
		/*,
		new BundleAnalyzerPlugin({
			analyzerMode:  'static',
			openAnalyzer:  true
		})*/
	],
	optimization: {
		minimizer: [
			new UgLiftJsPlugin({
				cache: true,
				parallel: true,
				sourceMap: true
		}),
			new OptimizeCSSAssetsPlugin({}),
			new CopyWebpackPlugin([
			{
				from: './src/image/img/**',
				to: path.resolve(__dirname, 'dist')
			}, 
			{
				from: './src/image/icons/**',
				to: path.resolve(__dirname, 'dist')
			}
			]),
			new ImgWebpackPlugin()
		]
	}
};

module.exports = config;
