import angular from 'angular';

const blog = angular.module('blog', [require('angular-route')]).config(['$locationProvider','$routeProvider', ($locationProvider ,$routeProvider) => {
	
	$routeProvider.when('/', {
	
		controller:  'homeController',
		templateUrl: './src/view/home.html'
		
	}).when('/article', {
	
		controller: 'articleController',
		templateUrl: './src/view/article.html',
		
	}).otherwise('/');
	
	//$locationProvider.hashPrefix('').html5Mode({ enable: true });
	
}]);

export { blog };
