import { blog } from './../index.js';
import './../../scss/commentPanel.scss';
import commentPanel from './../../view/commentPanel.html';
import '../../scss/articleInfo.scss';
import articleInfo from '../../view/articleInfo.html';
import '../../scss/home.scss';
import '../../scss/article.scss';

blog.controller('homeController', ['$scope', ($scope) => {
	$scope.users = [
		{
			name: 'jesus212',
			genre: 'hombre',
			flag: 'administrador',
			password: '123',
			photo: './src/image/icons/icons8-user-male-90.png',
			is_logged: false
		},
		{
			name: 'mary443',
			genre: 'mujer',
			flag: 'blogger',
			password: '123',
			photo: './src/image/icons/icons8-female-user-90.png',
			is_logged: false
		},
		{
			name: 'juancho45',
			genre: 'hombre',
			flag: 'usuario',
			password: '123',
			photo: './src/image/icons/icons8-user-male-90.png',
			is_logged: false
		},
		{
			name: 'an@902',
			genre: 'mujer',
			flag: 'usuario',
			password: '123',
			photo: './src/image/icons/icons8-female-user-90.png',
			is_logged: false
		}
	];
	$scope.articles = [
		{
			title: 'Gana dinero con hive work',
			image: './src/image/img/hive-work-logo.png',
			url: '/#!/article'
		}/*,
		{
			title: 'Article 1',
			image: './src/image/img/empty.jpg',
			url: '/#!'
		},
		{
			title: 'Article 2',
			image: './src/image/img/empty.jpg',
			url: '/#!'
		},
		{
			title: 'Article 3',
			image: './src/image/img/empty.jpg',
			url: '/#!'
		},
		{
			title: 'Article 4',
			image: './src/image/img/empty.jpg',
			url: '/#!'
		},
		{
			title: 'Article 5',
			image: './src/image/img/empty.jpg',
			url: '/#!'
		}*/
	];
}]).directive('articleInfo', ['$compile', ($compile) => {
	return {
		restrict: 'E',
		controller: 'homeController',
		scope: {
			info: '='
		},
		template: articleInfo
	}
}]).controller('articleController', ['$scope', '$controller', ($scope, $controller) => {
		const globalController = $scope.$new();
		$controller('homeController', { $scope: globalController });
		$scope.articles = globalController.articles;
		$scope.hivemicro = "https://hivemicro.com";
		$scope.hash_value = "HA8UES";
		$scope.referal= $scope.hivemicro + "?r=" + $scope.hash_value;
	}]).directive('commentPanel',['$compile', ($compile) => {
		return {
			controller: 'homeController',
			restrict: 'E',
			scope: {
				info: '='
			},
			link: (scope, element, attrs) => {
				scope.comment = element.val();
				
				scope.comments = [];
				scope.clicked = false;
				
				scope.index = 0;
				
				scope.likes = () => {
					return scope.comments[scope.index].like++;
				};
				scope.dislikes = () => {
					return scope.comments[scope.index].dislike++;
				};
				
				scope.clickComm = (user_comments) => {
					
					scope.comments.push({
						my_comment: user_comments,
						like: 0,
						dislike: 0,
						clicked_respond: false,
						is_selected: false
					});
					
					console.log("referal: " + scope.referal);
					scope.comment = "";
					}
					
				scope.selected = (event) => {
					const body_comment = $('.body_comment');
					scope.comments[scope.index].is_selected = true;
					scope.index = body_comment.index(event.currentTarget);
					//console.log(scopºe.comments[scope.index].is_selected);
				}
					
				scope.unselected = (event) => {
					scope.comments[scope.index].is_selected = false;
					//console.log(scope.index);
				}
				scope.clickRespond = () => {
					const respond = $('.subpanel');
					const respond_panel = (
						'<div class="respond_comment">'+
							'<form>'+
								'<div class="form-group">'+
									'<textarea></textarea>'+
								'</div>'+
								'<div class="form-group">'+
									'<button>Comentar</button>'+
								'</div>'+
							'</form>'+
						'</div>'
					);
					scope.comments[scope.index].clicked_respond = !scope.comments[scope.index].clicked_respond;
					if(scope.comments[scope.index].clicked_respond === true) {
						$($compile(respond_panel)(scope)).insertAfter(respond);
					}
					if(scope.comments[scope.index].clicked_respond === false) {
						$('.respond_comment').remove();
					}
				}
				
			},
			template: commentPanel
		};
	}]
);
