import { blog } from './../index.js';
import './../../scss/commentPanel.scss';
import './../../scss/article.scss'
import commentPanel from './../../view/commentPanel.html';

blog.controller('articleController', ['$scope', ($scope) => {
		$scope.title = "Gana dinero con hive work";
		$scope.hivemicro = "https://hivemicro.com";
		$scope.hash_value = "HA8UES";
		$scope.referal= $scope.hivemicro + "?r=" + $scope.hash_value;
	}]).directive('commentPanel',['$compile', ($compile) => {
		return {
			restrict: 'E',
			scope: {
				info: '='
			},
			link: (scope, element, attrs) => {
				scope.comment = element.val();
				
				scope.comments = [];
				scope.clicked = false;
				
				scope.index = 0;
				
				scope.likes = () => {
					return scope.comments[scope.index].like++;
				};
				scope.dislikes = () => {
					return scope.comments[scope.index].dislike++;
				};
				
				scope.clickComm = (user_comments) => {
					
					scope.comments.push({
						my_comment: user_comments,
						like: 0,
						dislike: 0,
						clicked_respond: false,
						is_selected: false
					});
					
					scope.comment = "";
					}
					
				scope.selected = (event) => {
					const body_comment = $('.body_comment');
					scope.comments[scope.index].is_selected = true;
					scope.index = body_comment.index(event.currentTarget);
					console.log(scope.comments[scope.index].is_selected);
				}
					
				scope.unselected = (event) => {
					scope.comments[scope.index].is_selected = false;
					console.log(scope.index);
				}
				scope.clickRespond = () => {
					const respond = $('.subpanel');
					const respond_panel = (
						'<div class="respond_comment">'+
							'<form>'+
								'<div class="form-group">'+
									'<textarea></textarea>'+
								'</div>'+
								'<div class="form-group">'+
									'<button>Comentar</button>'+
								'</div>'+
							'</form>'+
						'</div>'
					);
					scope.comments[scope.index].clicked_respond = !scope.comments[scope.index].clicked_respond;
					if(scope.comments[scope.index].clicked_respond === true) {
						$($compile(respond_panel)(scope)).insertAfter(respond);
					}
					if(scope.comments[scope.index].clicked_respond === false) {
						$('.respond_comment').remove();
					}
				}
			},
			template: commentPanel
		};
	}]
);
