import angular from 'angular';

angular.module('blog', [require('angular-route')])
