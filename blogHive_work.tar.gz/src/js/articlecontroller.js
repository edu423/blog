import { blog } from './blog.js';
import appInfo from './commentPanel.html';

blog.controller('articleController', ['$scope', ($scope) => {
		$scope.title = "Gana dinero con hive work";
		$scope.hivemicro = "https://hivemicro.com";
		$scope.hash_value = "HA8UES";
		$scope.referal= $scope.hivemicro + "?r=" + $scope.hash_value;
		
	}]
).directive('commentPanel',['$compile', ($compile) => {
		return {
			restrict: 'E',
			scope: {
				info: '='
			},
			link: (scope, element, attrs) => {
				scope.comment = element.val();
				
				scope.comments = [];
				scope.clicked = false;
				
				scope.index = 0;
				
				
				scope.likes = () => {
					return scope.comments[scope.index].like++;
				};
				scope.dislikes = () => {
					return scope.comments[scope.index].dislike++;
				};
				
				scope.count = 0;
				scope.counter = () => {
					return scope.count++;
				};
				
				scope.clickComm = (user_comments) => {
					const body_comment = $('.body_comment');
					const comment_body = ( 
					 '<div class="body_comment" ng-mouseenter="subpanel_on($event)" ng-mouseleave="subpanel_off()">'+
							'<div class="row">'+
								'<div class="col-sm-12">' +
									'<ul class="list-inline">' +
										'<li class="list-inline-item">' +
											'<img src="./src/image/icons/icons8-user-male-30.png" />' +
										'</li>'+
										'<li class="list-inline-item">'+
												'user_name'+
										'</li>'+
									'</ul>'+
								'</div>'+
							'</div>'+
							'<div class="row">'+
								'<div class="col-sm-12">'+
									'<p class="read_comment">'+ user_comments +'</p>'+
								'</div>'+
							'</div>'+
						'</div>'
					);
		
					scope.comments.push({
						my_comment: user_comments,
						like: 0,
						dislike: 0,
						clicked_respond: false,
						is_selected: false
					});
					element.append($compile(comment_body)(scope));
					//scope.index = comment_container.index(event.currentTarget);
					//console.log("scope.index: " + scope.index);
					scope.comment = "";
					}
					
				scope.subpanel_on = (event) => {
					const body_comment = $('.body_comment');
					const subpanel = blog.element(event.currentTarget);
					scope.index = body_comment.index(event.currentTarget);
					const subpanel_template = (
					'<div class="subpanel-'+ scope.index +'">'+
						'<ul class="list-inline">'+
							'<li class="list-inline-item">'+
								'<a href="" ng-click="clickRespond()">Responder</a>'+
							'</li>'+
							'<li class="list-inline-item">'+
								'Compartir'+
							'</li>'+
							'<li class="list-inline-item" ng-click="likes()">'+
								'<span>{{comments[index].like}}</span> <a href="">like</a>'+
							'</li>'+
							'<li class="list-inline-item" ng-click="dislikes()">'+
								'<span>{{comments[index].dislike}}</span> <a href="">dislike</a>'+
							'</li>'+
						'</ul>'+
					'</div>');
					scope.comments[scope.index].is_selected = true;
					if(scope.comments[scope.index].clicked_respond === false)
						subpanel.append($compile(subpanel_template)(scope));
					subpanel.css({
						backgroundColor: "#F0DD67",
						border: "1px solid black",
						overflow: "hidden"
					});
					console.log("id: "+ scope.index+ " is_selected: "+ scope.comments[scope.index].is_selected);
				}
					
				scope.subpanel_off = () => {
					const subpanel = $('.subpanel-' + scope.index);
					scope.comments[scope.index].is_selected = false;
					//if(scope.comments[scope.index].clicked_respond === false) {
						subpanel.remove();
					//}
					console.log("id: "+ scope.index+ " is_selected: "+ scope.comments[scope.index].is_selected);
				}
				scope.clickRespond = () => {
					const respond = $('.subpanel-' + scope.index);
					const respond_panel = (
						'<div class="respond_comment">'+
							'<form>'+
								'<div class="form-group">'+
									'<textarea></textarea>'+
								'</div>'+
								'<div class="form-group">'+
									'<button>Comentar</button>'+
								'</div>'+
							'</form>'+
						'</div>'
					);
					scope.comments[scope.index].clicked_respond = !scope.comments[scope.index].clicked_respond;
					if(scope.comments[scope.index].clicked_respond === true) {
						$($compile(respond_panel)(scope)).insertAfter(respond);
					}
					if(scope.comments[scope.index].clicked_respond === false) {
						$('.respond_comment').remove();
					}
				}
			},
			template: [appInfo]
		};
	}]
);
