module.exports = {
    pulgins: [
        require('precss'),
        require('autoprefixer')
    ]
}
